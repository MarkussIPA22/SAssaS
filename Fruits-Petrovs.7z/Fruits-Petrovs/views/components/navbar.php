<header>
        <nav>
            <a class="text-blue" href="/">Fruits</a>
            <a href="/create">Create a Fruit</a>
    </nav>
</header>