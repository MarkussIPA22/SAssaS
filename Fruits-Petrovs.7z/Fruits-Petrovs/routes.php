<?php

return [
    "/" => "controllers/fruits/index.php",
    "/delete" => "controllers/fruits/delete.php",
    "/create" => "controllers/fruits/create.php",
    "/show" => "controllers/fruits/show.php",
    "/edit" => "controllers/fruits/edit.php"
];