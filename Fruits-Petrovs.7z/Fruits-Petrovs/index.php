<?php 
require "functions.php";
require "router.php";