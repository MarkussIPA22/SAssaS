<?php require "components/navbar.php" ?>

<h1>404</h1>
