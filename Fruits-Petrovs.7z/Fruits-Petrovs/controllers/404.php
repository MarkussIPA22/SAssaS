<?php

require "views/404.view.php";